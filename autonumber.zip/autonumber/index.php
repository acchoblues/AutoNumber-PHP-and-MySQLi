<?php include "conn.php";
session_start();
 ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="Autonumber dengan PHP">
    <meta name="author" content="Hakko Bio Richard">
    <link rel="icon" href="../../favicon.ico">

    <title>Example Autonumber dengan PHP</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="dashboard.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="assets/js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    
  </head>

  <body>

    <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="http://www.hakkoblogs.com">Auto Number</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="#">Profile</a></li>
            <li><a href="#">Logout</a></li>
          </ul>
          <form class="navbar-form navbar-right">
            <input type="text" class="form-control" placeholder="Search...">
          </form>
        </div>
      </div>
    </nav>

    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
          <ul class="nav nav-sidebar">
            <li class="active"><a href="http://www.hakkoblogs.com">Dashboard <span class="sr-only"></span></a></li>
            <li><a href="http://www.hakkoblogs.com">Free Source</a></li>
            <li><a href="http://www.hakkoblogs.com">Tutorial</a></li>
            <li><a href="http://www.hakkoblogs.com">PHP, MySQLi & Bootstrap</a></li>
          </ul>
        </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
          <h1 class="page-header">Input Mahasiswa</h1>
<?php
			if(isset($_POST['input'])){
				$nim	     = $_POST['nim'];
				$nama	     = $_POST['nama'];
				$alamat      = $_POST['alamat'];
				$no_telp     = $_POST['no_telp'];
				$tahun_masuk = $_POST['tahun_masuk'];
                $jurusan     = $_POST['jurusan'];
                $jenjang     = $_POST['jenjang'];
				
				$cek = mysqli_query($koneksi, "SELECT * FROM mahasiswa WHERE nim='$nim'");
				if(mysqli_num_rows($cek) == 0){
						$insert = mysqli_query($koneksi, "INSERT INTO mahasiswa(nim, nama, alamat, no_telp, tahun_masuk, jurusan, jenjang)
															VALUES('$nim', '$nama', '$alamat', '$no_telp', '$tahun_masuk', '$jurusan', '$jenjang')") or die(mysqli_error());
						if($insert){
							echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Data Berhasil Di Simpan.</div>';
						}else{
							echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Ups, Data Gagal Di simpan !</div>';
						}
				}else{
					echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>NIM Sudah Ada..!</div>';
				}
			}
			?>
          <div class="row placeholders">
            <div class="jumbotron"> 
  <form class="form-horizontal"  action="index.php" enctype="multipart/form-data" onsubmit="return validateForm()" method="GET">    
  <div class="form-group">
			<label class="col-md-4 control-label" for="textinput">Jurusan </label>  
			<div class="col-md-4">
				 <select id="jurusan" name="jurusan" class="form-control" style="width:350px;"   required>
						<option>---- Pilih Jurusan ----</option>	
						<?php
						$sql = mysqli_query($koneksi, "SELECT * FROM jurus ORDER BY id");		
							if (mysqli_num_rows($sql) !=0) {							
								while($row = mysqli_fetch_assoc($sql)){		
								echo '<option value='.$row['kode_jur'].'>'.$row['kode_jur'].' - '.$row['jurusan'].'</option>';
								$_SESSION['jurusan'] = $row['kode_jur'];
								}
							}
							 
						?>
			</select>
	<!--	 
//echo substr('hasna', 1); //hasil = asna
 // echo substr('hasna ', 1, 3);   //hasil = asn
//echo substr('hasna ', 0, 4);   //hasil = hasn
//echo substr('hasna ', 0, 8);   //hasil = hasna
//echo substr('hasna ', -1, 1);  //hasil = a
//  -->
			</div>
		</div>
        <div class="form-group">
			<label class="col-md-4 control-label" for="textinput">Jenjang</label>  
				<div class="col-md-4">
					<select id="jenjang" name="jenjang" onchange="this.form.submit()" class="form-control" style="width:350px"   required>
						<option>---- Pilih Jenjang Pendidikan ----</option>	
				 <?php
						$sql = mysqli_query($koneksi, "SELECT * FROM jenjang ORDER BY id");		
							if (mysqli_num_rows($sql) !=0) {							
								while($row = mysqli_fetch_assoc($sql)){		
								echo '<option value='.$row['kode_jen'].'>'.$row['kode_jen'].' - '.$row['jenjang'].'</option>';
								$_SESSION['jenjang'] = $row['kode_jen'];
                                }
							}
						?>
					</select>
				</div>
		</div>
        </form>
        <!--<form class="form-horizontal"  action="inventoryitem_add.php" enctype="multipart/form-data" onsubmit="return validateForm()" method="GET">
        
        </form>-->
        
		<form name="myForm" class="form-horizontal"  action="" enctype="multipart/form-data" onsubmit="return validateForm()" method="post" >
		<fieldset>

<div class="form-group">
			<label class="col-md-4 control-label" for="textinput">NIM </label> 
            <div>
            <input type="hidden" id="jurusan" name="jurusan" value="<?php if(isset($_GET['jurusan'])){ echo $_GET['jurusan']; $_SESSION['a']=$_GET['jurusan']; }?>" class="form-control input-sm" style="width:150px;" maxlength="30">
            </div> 
            <div>
            <input type="hidden" id="jenjang" name="jenjang" value="<?php if(isset($_GET['jenjang'])){ echo $_GET['jenjang']; $_SESSION['b']=$_GET['jenjang']; }?>" class="form-control input-sm" style="width:150px;" maxlength="30">
            </div>
				<div class="col-md-4">
                <?php
                if(isset($_GET['jurusan']) && isset($_GET['jenjang'])){
       $ceknomor= mysqli_query($koneksi, "SELECT nim FROM mahasiswa WHERE jurusan='$_GET[jurusan]' AND jenjang='$_GET[jenjang]' ORDER BY nim DESC");
       //$ceknomor= mysqli_query($koneksi, "SELECT f_kodepart FROM t_inventoryitems ORDER BY f_kodepart DESC");
        
        $data=mysqli_num_rows($ceknomor);
        $cekQ=$data;
        //$data=mysqli_fetch_array($ceknomor);
        //$cekQ=$data['f_kodepart'];
        #menghilangkan huruf
        $awalQ=substr($cekQ,0-6);
        #ketemu angka awal(angka sebelumnya) + dengan 1
        $next=$awalQ+1;

        #menhitung jumlah karakter
        $kode=strlen($next);
        
        if(!$cekQ)
        { $no='00000'; }
        elseif($kode==1)
        { $no='00000'; }
        elseif($kode==2)
        { $no='0000'; }
        elseif($kode==3)
        { $no='000'; }
        elseif($kode==4)
        { $no='00'; }
        elseif($kode==5)
        { $no='0'; }
        elseif($kode=6)
        { $no=''; }
        
#Pembuatan kodepart baru

//$items=$_SESSION['a'].'-'.$_SESSION['b'].'-'.$no.$next;
//if(isset($_GET['movecategory']) && isset($_GET['movecategory'])){ $items=$_GET['plantname'].'-'.$_GET['movecategory'].'-'.$no.$next;} else { $items ="Auto Number";}
//$_SESSION['items'] = $items; 
$items=$_GET['jenjang'].'-'.$_GET['jurusan'].'-'.$no.$next;

}else { $items ="Auto Number";}
 ?>
                
                        <input type="text" id="nim" name="nim" value="<?php echo $items;?>" class="form-control" style="width:150px;" maxlength="30" readonly="readonly" >
				</div>
		</div>

		
<div class="form-group">
  <label class="col-md-4 control-label" for="textinput">Nama</label>  
  <div class="col-md-4">
    <input type="text" id="nama" name="nama" class="form-control" maxlength="40"  required autofocus >
 </div>
</div>

<div class="form-group">
  <label class="col-md-4 control-label" for="textinput">Alamat</label>  
  <div class="col-md-4">
    <input type="text" id="alamat" name="alamat" class="form-control" maxlength="100"  required autofocus >
 </div>
</div>
  
<div class="form-group">
  <label class="col-md-4 control-label" for="textinput">No Telepon</label>  
  <div class="col-md-4">
    <input type="text" id="no_telp" name="no_telp" class="form-control" maxlength="12"  required="number" autofocus >
 </div>
</div>


		
<div class="form-group">
			<label class="col-md-4 control-label" for="textinput">Tanggal Masuk</label>  
				<div class="col-md-4">
						<input id="tahun_masuk" name="tahun_masuk" class="form-control" type="text" value= "<?php echo date('Y-m-d'); ?>" readonly="readonly" >
						
						
 

				</div>
		</div>	
 
	<div class="form-group">
			<label class="col-md-4 control-label" for="textinput"></label>  
				<div class="col-md-4">
					<input type="submit" name="input" value="Simpan" class="btn btn-sm btn-primary pull-left" />
                    <a href="index.php" class="btn btn-sm btn-danger">Refresh</a>
				</div>
	</div> 
	
</fieldset>
</form>

</div>
          </div>

          <h2 class="sub-header">Data Mahasiswa</h2>
          <div class="table-responsive">
            <?php
                    $query1="select * from mahasiswa";
                    
                    $tampil=mysqli_query($koneksi, $query1) or die(mysqli_error());
                    ?>
                  <table id="example" class="table table-hover table-bordered">
                  <thead>
                      <tr>
                        <th><center>No </center></th>
                        <th><center>Nim </center></th>
                        <th><center>Nama </i></center></th>
                        <th><center>Alamat </center></th>
                        <th><center>No Telp </center></th>
                        <th><center>Tahun </center></th>
                        <th><center>Jurusan </center></th>
                        <th><center>Jenjang </center></th>
                      </tr>
                  </thead>
                     <?php 
                     $no=0;
                     while($data=mysqli_fetch_array($tampil))
                    { $no++; ?>
                    <tbody>
                    <tr>
                    <td><center><?php echo $no; ?></center></td>
                    <td><center><?php echo $data['nim'];?></center></td>
                    <td><a href="#"><span class="glyphicon glyphicon-user"></span> <?php echo $data['nama'];?></a></td>
                    <td><?php echo $data['alamat']; ?></td>
                    <td><center><?php echo $data['no_telp']; ?></center></td>
                    <td><center><?php echo $data['tahun_masuk'];?></center></td>
                    <td><center><?php echo $data['jurusan'];?></center></td>
                    <td><center><?php echo $data['jenjang'];?></center></td>
                    </tr><?php   
              } 
              ?>
              </tbody>
                   </table>
          </div>
        </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="js/bootstrap.min.js"></script>
    <!-- Just to make our placeholder images work. Don't actually copy the next line! -->
    <script src="assets/js/vendor/holder.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="assets/js/ie10-viewport-bug-workaround.js"></script>
  </body>
</html>
